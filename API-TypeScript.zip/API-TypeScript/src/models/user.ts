import {Schema, model} from 'mongoose';

const userSchema =new Schema({
    name: {type:String, required:true},
    email: {type:String, required:true, unique:true},
    password: {type:String, required:true},
    username: {type:String, required:true},
    createdAt: {type:Date, default: Date.now()},
    //Un usuario puede tener muchas publicaciones "JOIN" en mongodb
    posts: [{
        //de tipo esquema, obtiene el id
        type: Schema.Types.ObjectId,
        //hace rfcia al modelo post.ts
        ref: 'Post'
    }]
});

export default model('User', userSchema);