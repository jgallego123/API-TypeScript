import {Request, Response, Router} from 'express';
//importar modelo
import post from '../models/post';

class PostsRoutes{

    router:Router;

    constructor(){
        this.router = Router();        
        this.routes(); 
    }
    //Todas las publicaciones
    public async getPosts(req:Request, res:Response) :Promise<void>{
        //Consultar BD y devolver todas las publicaciones
        //await porque find se va a tomar su tiempo, por lo tanto metodo async
        const posts = await post.find();
        //Devuelve las publicaciones encontradas
        res.json(posts);
    }
    //Una sola publicacion 
    public async getPost(req:Request, res:Response) :Promise<void>{
        //Verifica que llegue la url
        //console.log(req.params.url);
        //Buscar en la BD y findOne devuelve un objeto y no un arreglo
        const Post = await post.findOne({url: req.params.url});
        res.json(Post);
    }

    public async createPost(req:Request,res:Response) :Promise<void>{
        //req.body: datos que el cliente va a enviar
        //console.log(req.body);
        //Nombre de las variables para crear en postman
        const {title, url, content, image} = req.body;
        const newPost = new post ({title, url, content, image});
        await newPost.save();
        res.json({data: newPost});
    }

    public async updatePost(req:Request,res:Response) :Promise<void>{
        //trayendo la url para buscar 
        //console.log(req.params.url);
        //trayendo el resto del body: title, content, image
        //console.log(req.body);
        //Desde req.params, almacena la url
        const {url} = req.params;
        //busca en BD y actualiza directamente --> (parametro por el que busca, nuevos datos, mostrar objeto actualizado)
        const Post = await post.findOneAndUpdate({url}, req.body, {new: true});
        res.json(Post);
        //busca en BD y actualiza directamente
        //post.findByIdAndUpdate
    }

    public async deletePost(req:Request,res:Response) :Promise<void>{
        const {url}=req.params;
        await post.findOneAndDelete({url});
        res.json('publicacion eliminada');
    }
    
    routes(){
        //ruta para devolver varias publicaciones
        this.router.get('/', this.getPosts);
        //una sola publicacion
        this.router.get('/:url', this.getPost);
        //crear publicacion
        this.router.post('/', this.createPost);
        //actualizar publicacion
        this.router.put('/:url', this.updatePost);
        //eliminar publicacion
        this.router.delete('/:url', this.deletePost);

    }
}

const postRoutes = new PostsRoutes();
export default postRoutes.router;
