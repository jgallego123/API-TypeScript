import {Request, Response, Router} from 'express';

class IndexRoutes {
    //Se inicializa 'router' de tipo Router
    router:Router;

    constructor(){
        //'router' ejecuta el metodo Router()
        this.router = Router();
        this.routes();
    }
    routes(){
        this.router.get('/', (req,res)=> res.send('Inicio'));
    }

}

const indexRoutes = new IndexRoutes();
indexRoutes.routes();
//Solo se necesita al enrutador 'router' que me devuelve el objeto
export default indexRoutes.router;