import {Request, Response, Router} from 'express';

import user from '../models/user';

class UserRoutes{

    router:Router;

    constructor(){
        this.router = Router();        
        this.routes(); 
    }
    public async getUsers(req:Request, res:Response) :Promise<void>{
        const users = await user.find();
        res.json(users);
    }
    public async getUser(req:Request, res:Response) :Promise<void>{
        //populate, acumula todos los datos de una publicacion en la variable post del modelo de user
        const User = await user.findOne({username: req.params.username}).populate('posts');
        res.json(User);
    }
    public async createUser(req:Request,res:Response) :Promise<void>{
        const newUser = new user (req.body);
        await newUser.save();
        res.json({data: newUser});
    }
    public async updateUser(req:Request,res:Response) :Promise<void>{
        const {username} = req.params;
        const User = await user.findOneAndUpdate({username}, req.body, {new: true});
        res.json(User);
    }

    public async deleteUser(req:Request,res:Response) :Promise<void>{
        const {username}=req.params;
        await user.findOneAndDelete({username});
        res.json({response: 'usuario eliminado'});
    }
    
    routes(){
        this.router.get('/', this.getUsers);
        this.router.get('/:username', this.getUser);
        this.router.post('/', this.createUser);
        this.router.put('/:username', this.updateUser);
        this.router.delete('/:username', this.deleteUser);
    }
}

const userRoutes = new UserRoutes();
export default userRoutes.router;