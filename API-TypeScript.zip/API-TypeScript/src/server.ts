import express from 'express';
import morgan from 'morgan';
import helmet from 'helmet';
import mongoose from 'mongoose';
import compression from 'compression';
import cors from 'cors';


import indexRoutes from './routes/indexRoutes';
import postsRoutes from './routes/postsRoutes';
import usersRoutes from './routes/userRoutes';


class Server{
    //Variable 'app' de tipo express application.
    public app:express.Application;
    constructor(){
        //inicializa el servidor
        this.app=express();
        //Despues de inicializado, se configura el servidor
        this.config();
        this.routes();
    }
    config(){
        //Direccion de la BD
        const MONGO_URI = 'mongodb://localhost/restapi';
        mongoose.set('useFindAndModify',  true);
        mongoose.connect(MONGO_URI || process.env.MONGODB_URL, {
            useNewUrlParser: true,
            useCreateIndex: true
        })
        //promise, si conecta la BD
        .then(db => console.log('BD conectada'));
        //Configuracion del servidor y puerto
        this.app.set('port', process.env.PORT || 2000);
        //middlewares
        this.app.use(morgan('dev'));
        this.app.use(express.json());
        this.app.use(express.urlencoded({extended:false}));
        this.app.use(helmet());
        this.app.use(compression());
        this.app.use(cors());
    }
    routes(){
        //app usa rutas de inicio indexRoutes
        this.app.use(indexRoutes);
        this.app.use('/api/posts',postsRoutes);
        this.app.use('/api/users',usersRoutes);
    }
 
    start(){
        //usa config para inicializar el servidor
        this.app.listen(this.app.get('port'), () => {
            //imprime cuando inicializa el servidor el puerto en el que esta escuchando
            console.log('Server on port: ', this.app.get('port'))
        });
    }

}
//La clase me devuelve un objeto, se guarda en una constante y 
//contiene todos los metodos y propiedades instanciadas en la clase
const server = new Server();
//inicializa la variable server
server.start();